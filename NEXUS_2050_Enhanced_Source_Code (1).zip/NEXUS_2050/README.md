# NEXUS 2050 — Future City Command

An interactive educational smart-city sustainability simulator. Players act as city architects and explore how infrastructure choices, resource trade-offs, crisis responses, and policy settings can influence a fictional city's modeled outcomes.

## Run locally
No build tools or package installation are required.

1. Download and extract the project.
2. Open `index.html` in a modern browser.
3. For a local development server, run `python -m http.server 8000` in this folder and visit `http://localhost:8000`.

## Files
- `index.html` — app structure and interface
- `style.css` — responsive dark neon visual system
- `app.js` — city state, builder, crisis scenarios, missions, charts, and interactions

## Features
- City dashboard with energy, water, air, happiness, and sustainability indicators
- City Builder with five upgrade types, credit costs, and changing city metrics
- Crisis Lab with four scenarios and three response choices per scenario
- Data Lab with four policy sliders and dynamically recalculated illustrative outcomes
- Missions, XP, ranks, progress tracking, and achievement indicators
- Responsive layout for desktop and mobile

## Important project notes
This is a self-contained front-end prototype. It does not require an API key or backend. The “NEXUS Insight Engine” uses transparent, rule-based educational logic; it is not a connected generative AI service. The Data Lab uses illustrative formulas, not measured city data or validated forecasts. The city and all scenarios are fictional.

## Suggested future work
- Connect a real backend for accounts and saved city states.
- Add sourced datasets from reputable public sources and cite them in an in-app methodology page.
- Validate simulation assumptions with urban-planning and sustainability references.
- Add accessible keyboard navigation, localization, and automated tests.
- Replace the illustrative skyline with a user-editable 3D city map.
